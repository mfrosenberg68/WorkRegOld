#ifdef DEBUG
class D_Vector;
class D_Matrix;
class D_IVector;

typedef D_Vector  Vec;
typedef D_IVector IVec;
typedef D_Matrix  Mat;
/*TEX
The following define determines whether \name{Arrays} or \name{D\_Arrays}
are being used throughout the code.
*/
  
#define ARRAY       D_Array
#define NUMARRAY    D_NumArray
#define NUMARRAY2D  D_NumArray2D
#define ARRAY2D     D_Array2D
#else
class Vector;
class Matrix;
class IVector;

typedef Vector  Vec;
typedef IVector IVec;
typedef Matrix  Mat;
/*TEX
The following define determines whether \name{Arrays} or \name{D\_Arrays}
are being used throughout the code.
*/
  
#define ARRAY       Array
#define NUMARRAY    NumArray
#define NUMARRAY2D  NumArray2D
#define ARRAY2D     Array2D
#endif








