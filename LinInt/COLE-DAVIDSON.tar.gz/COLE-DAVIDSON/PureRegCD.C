#include <unistd.h>    
#include <iomanip.h>      // Formtierung Input/Output
#include <fstream.h>      // Einlesen/Schreiben in Files
#include <iostream.h>     // Input/Output-Operationen
#include <math.h>         // Default Mathematik-Bibliothek
//#include "tnumarray.h"    //DOLIB TemplatArrays :-)
//#include "tarray.h"       //DOLIB DoubleArrayx :-)
//#include "error.h"        //Fehlerroutine DOLIB     :-)
#include "vtype.h"
#include "stringc.h"
#include "qc_utilities.H"



static double pi = 4.0 * atan(1.0); // pi als double 
static double SQRTPI = sqrt(pi); // pi als double 


double ColeDavidson(double x_, double b_, double t0)
{
 
  double t = exp(-x_);
  //  double t = x_;
  double y_, kern;
  
  if(t < t0)
    {
      kern = t /(t0 - t);
      //    y_ = factor * power(kern,b_)/t;
      y_ = pow(kern,b_);
    }
  else y_ = double(0.0);

  return y_ ;
}

double GAUSS(double x, double b)
{
  double y;
  y = exp(-b*b*x*x);
  return y;
}


int main()
{
  
  double beta,b,tau0;
  double xa,xb,M,h;
  double x1,x2,N,step;
  double x0;
  double sum,x;
  
  cin >> b >> beta >> tau0;
  cin >> xa >> xb >> M;
  cin >> x1 >> x2 >> N;

  double factorcd = sin(pi*beta)/pi;
  double factorga = b/SQRTPI;
  h = (xb - xa)/M;
  step = (x2 - x1)/N;

  cout <<"b    = " << b << endl;
  cout <<"beta = " << beta << endl;
  cout <<"tau0 = " << tau0 << endl;
  cout << '\v';
  cout <<"xa = " << xa << endl;
  cout <<"xb = " << xb << endl;
  cout <<"M  = " <<  M << endl;
  cout <<"h  = " <<  h << endl;
  cout << '\v' ;
  cout <<"x1 = " << x1 << endl;
  cout <<"x2 = " << x2 << endl;
  cout <<"N  = " << N << endl;
  cout <<"h2 = " << step << endl;
  cout << '\v';
  cout <<"Gaussfaktor = " << factorga << endl;
  cout <<"CD-Faktor   = " << factorcd << endl;
  cout << '\v';

  String regdata = "PUREREG-CD-g";
  regdata = regdata + strdup(fix3(beta)) +"-b" + strdup(fix3(b)) + ".out";
  ofstream rout(regdata());
  rout << setiosflags(ios::uppercase);
  
  String l2 = "L2-PUREREG-ERROR-g";
  l2 = l2 + strdup(fix3(beta)) + "-b" + strdup(fix3(b)) + ".out";
  ofstream lout(l2());
  lout << setiosflags(ios::uppercase);

  String pdata = "PTAU-PUREREG-g";
  pdata = pdata + strdup(fix3(beta)) + "-b" + strdup(fix3(b)) + ".out";
  ofstream pout(pdata());
  pout << setiosflags(ios::uppercase);

  
  double CD, ErrorRel, diff;
  double L2Error = 0.0;

  cout <<"*** Begin: Integration ***" << endl;
  for(int j = 0; j <= N; j++)
    {
      x0 = x2 - j*step;
      sum = 0.0;
      
      for (int i = 1; i <= M; i++) 
	{
	  x = xb - i * h;
	  sum += GAUSS(x0-x,b)*ColeDavidson(x,beta,tau0);
	}
      
      sum *= h * factorga* factorcd;
      
      CD = factorcd * ColeDavidson(x0,beta,tau0);
      
      /*
      ErrorRel = fabs(sum - CD)/fabs(sum);
      ErrorRel *= 100.0;
      */
      
      diff = fabs(sum - CD);
      if(diff == 0.0)
	{
	  ErrorRel = diff;
	}
      else
	{ 
	  ErrorRel = diff/fabs(sum);
	  ErrorRel *= 100.0;
	}
      
      L2Error += (sum - CD)*(sum - CD);
     
//      cout << "+++ " << -x0 << '\t' << CD << '\t' << sum<< '\t' << ErrorRel << endl;
      rout << -x0 << '\t' << CD << '\t' << sum <<'\t' << ErrorRel << endl;
      pout << exp(-x0) << '\t' << exp(-x0)*CD << '\t' << exp(-x0)*sum << endl;
    } 
  cout <<"*** End: Integration ***" << endl;
  cout << '\v';

  L2Error *= step;

  cout <<"*** L2-Error = " << L2Error << " ***" << endl;
  lout <<"L2-Error = " << L2Error << endl;
  
 return 0;
}


