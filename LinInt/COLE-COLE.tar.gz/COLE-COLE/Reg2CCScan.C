#include <unistd.h>    
#include <iomanip.h>      // Formtierung Input/Output
#include <fstream.h>      // Einlesen/Schreiben in Files
#include <iostream.h>     // Input/Output-Operationen
#include <math.h>         // Default Mathematik-Bibliothek
//#include "nrutil.h"     //NRC Utilities
#include "tnumarray.h"    //DOLIB TemplatArrays :-)
#include "tarray.h"       //DOLIB DoubleArrayx :-)
#include "mpmod.H"        // multiprecision Bibliothek
#include "functionc.H"
#include "datac.H"
#include "interpol.H"
#include "random.H"
#include "error.h"        //Fehlerroutine DOLIB     :-)
#include "stringc.h"
#include "qc_utilities.H"
#include "vtype.h"

double UpperBound2(double sigma, double gamma)
{
  static double pi = 4.0 * atan(1.0);
//  double bound =  sigma/(pow(2.0*pi,1.5) *gamma) * exp(11.103/(gamma*gamma));
   double bound = .5*pow(2.0*pi,1.5) * sigma/gamma * exp(1.2337/(gamma*gamma));
  return bound;
}


int main()
{
  cout  << setiosflags(ios::uppercase);

  int controll_write_kernel;
  /*
  ofstream kout("KERNEL2.out");
  kout << setiosflags(ios::uppercase);
  */
  
  ofstream outs("Y2DS2.out");
  outs  << setiosflags(ios::uppercase);

  ofstream wout("WARNINGS.out");
  wout << setiosflags(ios::uppercase);


  /* Multiprecisionbibliothek initialisieren */
  mp_init();
  mp_real pi = mppic; // pi aus der Bibliothek !!!
  mp_real pi2 = pi * pi;

  static double  dpi = 4.0 * atan(1.0); // pi als double 
  
  cout << "*** COLE-COLE MODELL ***" << endl;
  cout << "*** Precision = " << mpipl << " ***" << endl;
  
  /* PARAMTER */
  /* Regularisierungsparameter */
  double db, db1, db2;
  mp_real b, b1, b2;
  int Nb;


  /* Paramter der Regularisierung (Integration)*/
  int M;               // Zahl der St�tzstellen

  double x1, x2;       //Anfangs-/Endpunkt
  mp_real mpx1, mpx2;
  static mp_real mpstepreg; //Schrittweite

  /* Datenparameter, Real- und Imaginaerteil sein diesbezueglich gleich */
  int MD; //Zahl der Daten
  double xa, xb; //Anfang-/Endpunkt der Daten
  double h;  //Datenschrittweite

  /* Intervall und Zahl der Datenpunkte der Regularisierten */
  int N; //Zahl der Datenpunkte 
  double xr1, xr2;  //Anfang- und Endpunkte des Intervalls
  
  /* Parameter des Cole-Davidson-Modelles */
  double beta, tau0;

  /* Parameter einlesen */
  cin >> controll_write_kernel;
  cin >> db1 >> db2 >> Nb;
  cin >> beta >> tau0;
  cin >> xa >> xb >> MD;
  cin >> x1 >> x2 >> M;  
  cin >> xr1 >> xr2 >> N;

  /* Konversionen der Parameter: double -> mp_real */
  mpx1 = mp_real(x1);
  mpx2 = mp_real(x2);
  b1    = mp_real(db1);
  b2    = mp_real(db2);

  /* Berechnung weiterer Paramter */
  
  /* Schrittweite RegScan */
  mp_real bstep = (b2 - b1)/mp_real(Nb);
  
  /* Schrittweite der Integration in der Regularisierung */
  mpstepreg = (mpx2 - mpx1)/mp_real(M);  

  /* Schrittweite der Regularisierten */
  double step2 = (xr2 - xr1)/N;

  String l2 = "L2-2ERROR-g";
  l2 = l2 + strdup(sci3(beta)) + "-MD" + strdup(fix3(MD)) + "-NB" + strdup(fix3(Nb)) + "-b1:" + strdup(sci3(db1)) + "-b2:" + strdup(sci3(db2)) + ".out";
  ofstream l2out(l2());
  l2out << setiosflags(ios::uppercase);


  cout << "*** Begin: Regularisation Scan ***" << endl;
  for(int l = 0; l <=Nb; l++)
  {
      b = b1 + l * bstep;
      db = dble(b);

      cout <<"*** j = " << l << '\t' << ": b = " << db << " ***" << endl;
      cout << '\v';
      
  /* DATEIEN */


  String data1 = "DATA2-E1-g";
  data1 = data1 +  strdup(sci3(beta)) + "-MD" + strdup(fix3(MD)) + ".out";
  ofstream d1out(data1());
  d1out << setiosflags(ios::uppercase);

  String data2 = "DATA2-E2-g";
  data2 = data2 +  strdup(sci3(beta)) + "-MD" + strdup(fix3(MD)) + ".out";
  ofstream d2out(data2());
  d2out << setiosflags(ios::uppercase);

  String lintdata1 = "DATA2E1LIP-g";
  lintdata1 = lintdata1 +  strdup(sci3(beta)) + "-MD" +strdup(fix3(MD)) + ".out";
  ofstream d1intout(lintdata1());
  d1intout << setiosflags(ios::uppercase);

  String lintdata2 = "DATA2E2LIP-g";
  lintdata2 = lintdata2 +  strdup(sci3(beta)) + "-MD" + strdup(fix3(MD)) + ".out";
  ofstream d2intout(lintdata2());
  d2intout << setiosflags(ios::uppercase);

  String regdatei1 = "REGE1CC-g";
  regdatei1 = regdatei1 +  strdup(sci3(beta)) + "-MD" + strdup(fix3(MD)) + "-b" + strdup(sci3(db)) + ".out";
  ofstream r1out(regdatei1());
  r1out << setiosflags(ios::uppercase);

  String regdatei2 = "REGE2CC-g";
  regdatei2 = regdatei2 +  strdup(sci3(beta)) + "-MD" + strdup(fix3(MD)) + "-b" + strdup(sci3(db)) + ".out";
  ofstream r2out(regdatei2());
  r2out << setiosflags(ios::uppercase);

  String d2mpe1 = "D2MPCC-E1-g";
  d2mpe1 = d2mpe1 + strdup(sci3(beta)) + "-b" + strdup(sci3(db)) + ".out";
  ofstream r1dout(d2mpe1());
  // ofstream r1dout("D2MPCC-E1.out");
  r1dout << setiosflags(ios::uppercase);

  String d2mpe2 = "D2MPCC-E2-g";
  d2mpe2 = d2mpe2 + strdup(sci3(beta)) + "-b" + strdup(sci3(db)) + ".out";
  ofstream r2dout(d2mpe2());
  //  ofstream r2dout("D2MPCC-E2.out");
  r2dout << setiosflags(ios::uppercase);

  
  String regcdm = "REGCCM-g";
  regcdm = regcdm +  strdup(sci3(beta)) + "-MD" + strdup(fix3(MD)) + "-b:" + strdup(sci3(db)) + ".out";
  ofstream mout(regcdm());
  mout << setiosflags(ios::uppercase);
  
  String pdat1 = "PTAU2-g";
  pdat1 = pdat1 +  strdup(sci3(beta)) + "-MD" + strdup(fix3(MD)) + "-b1:" + strdup(sci3(db)) + ".out";
  ofstream pout(pdat1());
  pout << setiosflags(ios::uppercase); 

  String pdat2 = "PTAUM2-g";
  pdat2 = pdat2 +  strdup(sci3(beta)) + "-MD" + strdup(fix3(MD)) + "-b:" + strdup(sci3(db)) + ".out";
  ofstream pmout(pdat2());
  pmout << setiosflags(ios::uppercase); 



  /* ---------------------------------------------------*/

  /* *** Regularisierungskerne und deren Vorfaktoren *** */

  /*  Deklarationen */
  static mp_real factorE1;
  static mp_real factorE2;
  static double dfactore1;
  static double dfactore2;
  
  NUMARRAY<mp_real> mpregKernE1(M+1);
  NUMARRAY<mp_real> mpregKernE2(M+1);

  //  D_NumArray<mp_real> mpregKernE1(M+1);
  //  D_NumArray<mp_real> mpregKernE2(M+1);
    
  /* Definition/Berechnung der Vorfaktoren der Regularisierungskerne */
  factorE1 = mp_real(2.0)*b/power(pi,mp_real(1.5));
  factorE1 *= exp(mp_real(0.25) * pi2 * b * b);
  
  factorE2 = mp_real(2.0)*b/power(pi,mp_real(1.5));
  factorE2 *= exp(mp_real(0.25) * pi2 * b * b);
  
  dfactore1 = 2.0 * (db/pow(dpi,1.5)) * exp(db*db*dpi*dpi*.25);
  dfactore2 = 2.0 * (db/pow(dpi,1.5)) * exp(db*db*dpi*dpi*.25);

  /* KERNELARRAYs auffuellen */

  cout << "*** Begin: Init. Kernelarrays ***" << endl;
  
  cout << "db = " << db  << endl;
  cout << "b  = " <<  b ;
  cout << "x1  = " << x1 << endl;  /* Anfangs-/Endpunkt der Regularisierung */
  cout << "x2  = " << x2 << endl;
  cout << "M   = " << M  << endl; 
  cout << "h   = " << mpstepreg;
  cout << "FactorE1  = " << factorE1 ;
  cout << "dfactore1 = " << dfactore1 << endl;
  cout << "FactorE2  = " << factorE2 ;
  cout << "dfactore2 = " << dfactore2 << endl;
  cout << '\v';

  mp_real mpx;
  
  for(int i = 0; i <= M; i++) 
    {
      mpx = mpx1 + i * mpstepreg;
      mpregKernE1[i] = mpregkerne1(mpx, b);
      mpregKernE2[i] = mpregkerne2(mpx, b);
    }

  cout << "*** End: Init. Kernelarrays *** " << endl;
  cout <<'\v';

  /* Kontrolle: Regularisierungskern ausgeben */
  if(controll_write_kernel == 1)
    {
      ofstream kout("KERNEL2.out");
      kout << setiosflags(ios::uppercase);
      cout <<"*** Begin: Write Regularisationkernels ***" << endl;

      //  cout << "*** Kernel Realteil ***" << endl;
      kout << "*** Kernel Realteil ***" << endl;
      for(int i = 0; i <= M; i++)
	{
	  mpx = mpx1 + i * mpstepreg;
	  //  cout << mpx << mpregkerne1(mpx,b1) << mpregKernE1[i] << endl;
	  mp_real controllkernel = abs(mpregkerne1(mpx,b) - mpregKernE1[i]);
	  if(controllkernel != mp_real(0.0)) error("Mismatch: Kernel and Kernelarray");  	  
	  kout << dble( mpregkerne1(mpx,b)) << '\t' <<  dble(mpregKernE1[i]) << endl;
	}
      
      //  cout << "*** Kernel Imagin�rteil ***" << endl;
      kout << "*** Kernel Imagin�rteil ***" << endl;
      for(int i = 0; i <= M; i++)
	{
	  mpx = mpx1 + i * mpstepreg;
	  //      cout << mpx << mpregkerne2(mpx,b2) << mpregKernE2[i] << endl;
	  mp_real controllkernel = abs(mpregkerne2(mpx,b) - mpregKernE2[i]);
	  if(controllkernel != mp_real(0.0)) error("Mismatch: Kernel and Kernelarray");  
	  kout << dble(mpregkerne2(mpx,b)) << '\t' <<  dble(mpregKernE2[i]) << endl;
	}
      cout <<"*** End: Write Regularisationkernels ***" << endl;
    }


  /* ------------------------------------------------------ */

  /* DATEN */
  /* Deklaration, Definition der Datenarrays */
  NUMARRAY<double> datae1(MD,1); /* Daten Realteil */
  NUMARRAY<double> datae2(MD,1); /* Date Imaginaerteil */
  NUMARRAY<double> x(MD,1);      /* x-Vektor, "Frequenzen"*/
  NUMARRAY<double> y2de1(MD,1); /* Vektor der lin. Interpolation des Realt. */
  NUMARRAY<double> y2de2(MD,1); /* Vektor der lin. Interpolation des Imagt. */
  
  h = (xb - xa)/(MD -1);
  double rho = MD/(xb -xa);

  cout << "*** Begin: Init. Data-Array ***" << endl;
  cout << "beta = "<< beta << endl;
  cout << "tau0 = " << tau0 << endl;
  cout << "xa   = " << xa << endl;   /* Anfangs-/Endpunkte der Daten */
  cout << "xb   = " << xb << endl;
  cout << "MD   = " << MD  << endl;  /* Zahl der Datenpunkte */
  cout << "h    = " << h  << endl;
  cout << "rho  = " << rho  << endl;
  
  x[1] = xa;
  datae1[1] = real(edata(xa,beta,tau0));
  datae2[1] = imag(edata(xa,beta,tau0));
  
  for(int i = 2; i < MD ; i++)
    {
      x[i] = xa + (i-1) * h;
      datae1[i] = real(edata(x[i],beta,tau0));
      datae2[i] = imag(edata(x[i],beta,tau0));
    }

  x[MD] = xb;
  datae1[MD] = real(edata(xb,beta,tau0));
  datae2[MD] = imag(edata(xb,beta,tau0));
  
  cout << "*** End: Init. Data-Array ***" << endl;
  cout << '\v' ;
  
  double DataErrore1, DataErrore2; //Relativer Datenfehler

  /* Kontrollausgabe, Datenausgabe */
  for(int i = 1; i <= MD; i++)
    {
      DataErrore1 = fabs(datae1[i] - real(edata_exakt(x[i],beta,tau0)))/fabs(real(edata_exakt(x[i],beta,tau0)));
      DataErrore1 *= 100.0;

      DataErrore2 = fabs(datae2[i] - imag(edata_exakt(x[i],beta,tau0)))/fabs(imag(edata_exakt(x[i],beta,tau0)));
      DataErrore2 *= 100.0;


      d1out << i << '\t' << x[i] << '\t' << datae1[i] << '\t' << real(edata_exakt(x[i],beta,tau0)) << '\t' << DataErrore1 << endl;
      d2out << i << '\t' << x[i] << '\t' << datae2[i] << '\t' << imag(edata_exakt(x[i],beta,tau0)) << '\t' << DataErrore2 << endl;
    }

  /* INTERPOLATION der Daten */

  double datae1linpol, datae2linpol; //interpolierte Real-/Imag. - Daten
  double step, x0;
  double E1, E2 , ErrorrelE1, ErrorrelE2;
  double L2_ErrorE1 = 0.0; 
  double L2_ErrorE2 = 0.0;
  
  cout << "*** Begin: Interpol. *** " << endl;

  /* Realteildaten interpolieren */
  intlinear(x,datae1,MD,y2de1);

  /* Imaginaerteildaten interpolieren */
  intlinear(x,datae2,MD,y2de2);
  
  for(int i = 1; i <= MD; i++) outs << i << '\t'  << y2de1[i] << '\t' << y2de2[i] << endl;
 
  /* Kontrollasugaben und Berechnung des Fehlers in der L2-Norm */

  
  for(int j = 0; j <= M; j++)
    {
      step = dble(mpstepreg);
      x0 = x1 + j * step;

      datae1linpol = linint(x,datae1,y2de1,MD,x0);
      datae2linpol = linint(x,datae2,y2de2,MD,x0);
      
      E1 = real(edata_exakt(x0,beta,tau0));
      E2 = imag(edata_exakt(x0,beta,tau0));

      ErrorrelE1 = fabs(datae1linpol - E1)/fabs(E1);
      ErrorrelE1 *= 100.0; // Relativfehler der interpolierten E1
      
      /* Berechnung: L2-Fehler der interpolierten E1 */
      L2_ErrorE1 += (datae1linpol - E1) * (datae1linpol - E1);

      ErrorrelE2 = fabs(datae2linpol - E2)/fabs(E2);
      ErrorrelE2 *= 100.0; // Realtivfehler der interpolierten e2
      
      /* Berechnung: L2-Fehler der interpolierten E2 */
      L2_ErrorE2 += (datae2linpol - E2) * (datae2linpol - E2);
      
      
      d1intout << x0 << '\t' << datae1linpol << '\t' << E1 << '\t'<< ErrorrelE1<< endl;

      d2intout << x0 << '\t' << datae2linpol << '\t' << E2 << '\t'<< ErrorrelE2<< endl;
    }

  L2_ErrorE1 *= step;
  L2_ErrorE2 *= step;

  cout << "*** End: Interpol. *** " << endl;
  cout << '\v';
  cout << "*** L2-Error E1 = " << L2_ErrorE1 << " ***" << endl;
  cout << "*** L2-Error E2 = " << L2_ErrorE2 << " ***" << endl;
  cout << '\v';

  /* ------------------------------------------------------*/


  /* Die REGULARISIERUNGSROUTINE */
  mp_real mprege1, mprege2, mpColeCole;
  double rege1, rege2, DBColeCole;

  mp_real mpRegRelErrorE1, mpRegRelErrorE2;
  double RegRelErrorE1, RegRelErrorE2;

  mp_real mprege1d2mp, mprege2d2mp;
  double  rege1d2mp, rege2d2mp;

  mp_real mp_d2mprele1, mp_d2mprele2;
  double  d2mprele1, d2mprele2;
  

  /* L2-Norm des gesamten Regularisierungsfehlers */
  double  L2rege1, L2rege2;
  mp_real mpL2rege1 = mp_real(0.0);
  mp_real mpL2rege2 = mp_real(0.0);

  
  double L2d2mpe1, L2d2mpe2;
  mp_real mpL2d2mprege1 = mp_real(0.0);
  mp_real mpL2d2mprege2 = mp_real(0.0);
  

  double mittel1, mittel2, gwmit;

  cout <<"*** Begin: Regularisation ***" << endl;
  cout << "b  = " << db  << endl;
  cout << "b  = " <<  b ;
  cout << "x1 = " << xr1 << endl;
  cout << "x2 = " << xr2 << endl;
  cout << "N  = " << N  << endl;
  cout << "h  = " << step2 << endl;
  cout << '\v' ;
  cout << "FactorE1  = " << factorE1 ;
  cout << "dfactore1 = " << dfactore1 << endl;
  cout << "FactorE2  = " << factorE2 ;
  cout << "dfactore2 = " << dfactore2 << endl;
  cout << '\v';

  double xi;
  for(int jj = 0; jj <= N; jj++)
    {
      mprege1 = mp_real(0.0);
      mprege2 = mp_real(0.0);

      mprege1d2mp = mp_real(0.0);
      mprege2d2mp = mp_real(0.0);
      
      x0 = xr1 + jj * step2;
      
      if(fabs(x0-x1) > fabs(xa)) wout <<"For x0 = " << x0 << endl;
      if(fabs(x0-x2) > fabs(xb)) wout <<"For x0 = " << x0 << endl;
      
      for(int j = 0; j <= M; j++)
	{
	  xi = x1 + j * step;
	  //xi = xi - x0;
	  xi = x0 - xi;

	  datae1linpol = linint(x,datae1,y2de1,MD,xi);
	  datae2linpol = linint(x,datae2,y2de2,MD,xi);
	  
	  mprege1 += mpregKernE1[j] * mp_real(datae1linpol);
	  mprege2 += mpregKernE2[j] * mp_real(datae2linpol);

	  /* d2m Integration */
	  mprege1d2mp += mpregKernE1[j] * mp_real(real(edata_exakt(xi,beta,tau0)));
	  mprege2d2mp += mpregKernE2[j] * mp_real(imag(edata_exakt(xi,beta,tau0)));
	  
	}
      
      mprege1 *= mp_real(-1.0)*mpstepreg * factorE1;
      mprege2 *= mp_real(-1.0)*mpstepreg * factorE2;

      mprege1d2mp *= mp_real(-1.0) * mpstepreg * factorE1;
      mprege2d2mp *= mp_real(-1.0) * mpstepreg * factorE2;
      
      mpColeCole = ColeCole(mp_real(-x0),mp_real(beta),mp_real(tau0)); 
   //mpColeCole = ColeCole(mp_real(x0),mp_real(beta),mp_real(tau0)); 
      
      mpRegRelErrorE1 = abs(mprege1 - mpColeCole)/abs(mprege1);
      mpRegRelErrorE1 *= mp_real(100.0);

      mpRegRelErrorE2 = abs(mprege2 - mpColeCole)/abs(mprege2);
      mpRegRelErrorE2 *= mp_real(100.0);

      mp_d2mprele1 = abs(mprege1d2mp - mpColeCole)/abs(mprege1d2mp);
      mp_d2mprele1 *= mp_real(100.0);

      mp_d2mprele2 = abs(mprege2d2mp - mpColeCole)/abs(mprege2d2mp);
      mp_d2mprele2 *= mp_real(100.0);

      mpL2rege1 += (mprege1 - mpColeCole) * (mprege1 - mpColeCole);
      mpL2rege2 += (mprege2 - mpColeCole) * (mprege2 - mpColeCole);

      mpL2d2mprege1 += (mprege1d2mp - mpColeCole)*(mprege1d2mp - mpColeCole);
      mpL2d2mprege2 += (mprege2d2mp - mpColeCole)*(mprege2d2mp - mpColeCole);

      /* Konversionen */

      rege1         = dble(mprege1);
      rege2         = dble(mprege2);
      DBColeCole     = dble(mpColeCole);
      RegRelErrorE1 = dble(mpRegRelErrorE1);
      RegRelErrorE2 = dble(mpRegRelErrorE2);
      rege1d2mp     = dble(mprege1d2mp);
      rege2d2mp     = dble(mprege2d2mp);
      d2mprele1     = dble(mp_d2mprele1);
      d2mprele2     = dble(mp_d2mprele2);

      mittel1 = .5*(rege1 + rege2);
      mittel2 = sqrt(.5 * (rege1*rege1 + rege2*rege2));
      //gwmit   = sqrt(db1*db1*rege1*rege1 + db2*db2*rege2*rege2))/(db1+db2);
      gwmit   = (db*rege1 + db*rege2)/(db+db);

      /*
      cout << x0 << endl;
      cout << mprege1 << mpColeCole << mpRegRelErrorE1 << endl;
      cout << mprege2 << mpColeCole << mpRegRelErrorE2 << endl;
      */
      r1out << x0 << '\t' << DBColeCole << '\t' << rege1 << '\t' << RegRelErrorE1 << '\t' << beta <<  endl;
      r2out << x0 << '\t' << DBColeCole << '\t' << rege2 << '\t' << RegRelErrorE2 << '\t' << beta <<  endl;

      pout << exp(x0) << '\t' << exp(-x0)*DBColeCole << '\t' << exp(-x0)*rege1 << '\t' << exp(-x0)*rege2 << '\t' << beta << endl;

      r1dout << x0 << '\t' << DBColeCole << '\t' << rege1d2mp << '\t' << d2mprele1 << '\t' << beta << endl;
      
      r2dout << x0 << '\t' << DBColeCole << '\t' << rege2d2mp << '\t' << d2mprele2 << '\t' << beta << endl;
	    
      mout << x0 << '\t' << DBColeCole << '\t' << mittel1  << '\t' << mittel2 << '\t' << gwmit << endl;

      pmout << exp(x0) << '\t' << exp(-x0)*DBColeCole << '\t' << exp(-x0)*mittel1  << '\t' << exp(-x0)*mittel2 << '\t' << exp(-x0)*gwmit << endl;

    }
    
  cout <<"*** End: Regularisation ***" << endl;
  mpL2rege1 *= step2;
  mpL2rege2 *= step2;
  mpL2d2mprege1 *= step2;
  mpL2d2mprege2 *= step2;
  
  L2rege1  = dble(mpL2rege1);
  L2rege2  = dble(mpL2rege2);
  L2d2mpe1 = dble(mpL2d2mprege1);
  L2d2mpe2 = dble(mpL2d2mprege2);

  double a1 = 1.0/(2.0*db);
  double a2 = 1.0/(2.0*db);
  double asympe1 = UpperBound2(L2_ErrorE1,a1);
  double asympe2 = UpperBound2(L2_ErrorE2,a2);

  cout << '\v';

  cout << "*** L2-Error E1     = " << L2_ErrorE1 << " ***" << endl;
  cout << "*** L2-Regerror  E1 = " << L2rege1 << " ***" << endl;
  cout << "*** L2-d2mperror E1 = " << L2d2mpe1 << " ***" << endl;
  cout << "*** asymp. Error E1 = " << asympe1 << " ***" << endl;
  cout << '\v';
  cout << "*** L2-Error E2     = " << L2_ErrorE2 << " ***" << endl;
  cout << "*** L2-Regerror  E2 = " << L2rege2 << " ***" << endl;
  cout << "*** L2-d2mperror E2 = " << L2d2mpe2 << " ***" << endl;
  cout << "*** asymp. Error E2 = " << asympe2 << " ***" << endl;  

  cout << '\v';
  l2out << "*** b           = " << db << " ***" << endl;               
  l2out << "L2-Error E1     = " << L2_ErrorE1 << endl;
  l2out << "L2-Regerror  E1 = " << L2rege1  << endl;
  l2out << "L2-d2mperror E1 = " << L2d2mpe1 << endl;
  l2out << "asymp. Error E1 = " << asympe1 << endl;
  
  l2out << "L2-Error E2     = " << L2_ErrorE2 << endl;
  l2out << "L2-Regerror  E2 = " << L2rege2 << endl;
  l2out << "L2-d2mperror E2 = " << L2d2mpe2 << endl;
  l2out << "asymp. Error E2 = " << asympe2 << endl;  

  }
  
  cout << "*** Begin: Regularisation Scan ***" << endl;
  return 0;
}
