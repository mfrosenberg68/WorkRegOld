#include <unistd.h>    
#include <iomanip.h>   // Formtierung Input/Output
#include <fstream.h>   // Einlesen/Schreiben in Files
#include <iostream.h>  // Input/Output-Operationen
#include <math.h>      // Default Mathematik-Bibliothek
#include "mpmod.H"
#include "vtype.h"
#include "qc_utilities.H"

/* Funktionen und Routinenen */

mp_real mptrapez(mp_real function(mp_real _x, mp_real _x0, mp_real _a, mp_real g_), mp_real _x0, mp_real _a, mp_real s_, mp_real h_, int n_, mp_real g_) 
{

  mp_real sum;
  mp_real zu, zd;
  //  cout <<"from trapez: s = " << s_ ;
  sum = function(s_,_x0,_a,g_);
  for (int i = 1; i <= n_ ; i++) {
    zu = s_ + i * h_ ;
    zd = s_ - i * h_ ;
    //    cout <<"from trapez: zu = " << zu;

    sum += function(zu,_x0,_a,g_) + function(zd,_x0,_a,g_);
  }
  
  return sum *= h_ ;
}

/* Reg. Kern der Ima-Gleichung */
mp_real mpregkerne2(mp_real x_, mp_real x0_, mp_real b_)
{
 static mp_real pi = mppic ;
 mp_real _y = exp(-b_ * b_ * (x0_ -x_) *(x0_ - x_)) * cos(pi * b_ * b_ * (x0_ -x_ ));
 return _y;
}

/* Cole-Cole Dichte f�r a=0.5 */
mp_real Regtheo(mp_real x_, mp_real b_)
{
    static mp_real pi = mppic;
    //  mp_real factor = sin(pi*(b_))/(mp_real(2.0)*pi);
    mp_real factor = sin(pi*(b_))/(mp_real(2.0)*pi);
//    mp_real x0 = -log(t0);
    mp_real y_;
    y_ = mp_real(1.0)/(cosh(b_ * x_) + cos(pi*b_));
    y_ *= factor;
    return y_;

}

/* Cole-Cole Eplus f�r a=0.5 */
mp_complex E_data(mp_real x, mp_real gamma)
{
  static mp_complex I = mp_complex(0.0,1.0);
  static mp_real pi = mppic;
//  const mp_real gamma = mp_real(0.5);
//  mp_complex g = mp_real(1.0)/(1.0 + sqrt(-I*exp(-x))); 
  mp_complex g = (mp_real(1.0) + exp(-gamma*x)*(cos(0.5*pi*gamma)-I*sin(0.5*pi*gamma))); 
  return mp_real(1.0)/g;
}

mp_real RegIntegrand(mp_real x, mp_real x0, mp_real b, mp_real gamma)
{
  mp_real Integrand = mpregkerne2(x,x0,b)*aimag(E_data(x,gamma));
  return Integrand;
}

mp_real MPRelError(mp_real a, mp_real b)
{
  if(a == 0)
    {
      return abs(b);
    }
  else
    {
      return 100.0*(abs(a-b)/abs(a));
    }

}

/* Das Hauptprogramm */


int main()
{
  cout << setiosflags(ios::uppercase);

  //ofstream dout("RegE2_MP.out");
  //dout  << setiosflags(ios::uppercase);

  mp_init();
  static mp_real pi  = mppic;
  static mp_real pi2 = mppic * mppic;
    
  static mp_real Sqrtpi = sqrt(mppic);
  
  cout  << setiosflags(ios::uppercase);

  /*
  ofstream out("REGSOLC.out");
  out << setiosflags(ios::uppercase);

  ofstream kout("KERNELCMP.out");
  kout << setiosflags(ios::uppercase);

  ofstream dout("DATACMP.out");
  dout << setiosflags(ios::uppercase);
   */
 
  int M, N, Nb;
  double bd, bd1, bd2;
  double x1d, x2d, xad, xbd;
  double dgamma;

  mp_real mpbstep, b;
  
  cin >> dgamma;
  cin >> bd1 >> bd2 >> Nb;
  cin >> xad >> xbd >> N;
  cin >> x1d >> x2d >> M;
  cout << "*** MP-Reg: IMAgl COLE-COLE MOD: gamma = " << dgamma << " ***" << endl; 

  cout << "*** Precision = " << mpipl << " ***" << endl;
  cout << "b1 = " << bd1 << endl;
  cout << "b2 = " << bd2 << endl;
  cout << "Nb = " << Nb << endl;
  cout << "xa = " << xad << endl;
  cout << "xb = " << xbd << endl;
  cout << "x1 = " << x1d << endl;
  cout << "x2 = " << x2d << endl;
  cout << "N  = " << N << endl;
  cout << "M  = " << M << endl;

  mp_real xa   = mp_real(xad);
  mp_real xb   = mp_real(xbd);
  mp_real x1   = mp_real(x1d);
  mp_real x2   = mp_real(x2d);
  mp_real b1   = mp_real(bd1);
  mp_real b2   = mp_real(bd2);
  mp_real gamma = mp_real(dgamma);

  if(Nb==0) mpbstep = mp_real(0.0);
  else mpbstep = (b2 - b1)/mp_real(Nb);
  
  cout << "bstep = " << mpbstep;


  mp_real h    = (xb - xa)/mp_real(N);
  cout << "h  = " << h ;
  
  mp_real step = (x2 - x1)/mp_real(M);
  cout << "h2 = " << step;

  cout << '\v';

  mp_real mpx0; 
  mp_real mpregsum;
  mp_real mpReg, RelError, mpL2_RegError;
  double RealReg, Error, L2_RegError;

  /* L2-Norm des Regularsierungsfehlers */
  mpL2_RegError = mp_real(0.0);

  String l2 = "L2-CC-E2-ERROR-gamma";
  l2 = l2 + strdup(fix3(dgamma)) + "-MD:" + strdup(fix3(N)) + "-xb" + x2d +"-Nb" +strdup(fix3(Nb))+ "-b1:" + strdup(fix3(bd1)) + "-b2:" + strdup(fix3(bd2)) + ".out";
  ofstream lout(l2());
  lout << setiosflags(ios::uppercase);



  cout << " *** Begin: Regularisationscan *** " << endl;

  for(int jj = 0; jj <= Nb; jj++)
  {
      b = b1 + jj*mpbstep;
      bd = dble(b);
      
      cout << "+++ j = " << jj << ", b = " << bd << " +++" << endl;  

      String regdatei2 = "REGCC-E2-gamma";
      regdatei2 = regdatei2 + strdup(fix3(dgamma)) + "-MD:" + strdup(fix3(N)) + "-xb" + x2d + "-b" + strdup(fix3(bd)) + ".out";
      ofstream out(regdatei2());
  out << setiosflags(ios::uppercase);
  

    /* Vorfaktor */
  mp_real factor;
  factor = mp_real(2.0)*b/power(pi,mp_real(1.5));
  factor *= exp(mp_real(0.25) * pi2 * b * b);


  for(int j = 0; j <= M; j++)
    {
      mpx0 = x1 + j * step;

      mpregsum = mptrapez(RegIntegrand,mpx0,b,mpx0,.5*h,N,gamma);
      mpregsum *=factor;

      mpReg = Regtheo(-mpx0,gamma);
      RelError = MPRelError(mpregsum, mpReg);

      mpL2_RegError += abs((mpregsum - mpReg)*(mpregsum - mpReg)) ;

//      cout << "x0 = " << dble(mpx0) << endl;
//      cout << mpregsum <<mpReg << RelError << endl;
      
      RealReg = dble(mpregsum);
//      ImaReg  = dble(aimag(mpregsum));
      Error   = dble(RelError);

 (ostream&) out << dble(mpx0) << '\t' << dble(mpReg) << '\t' << RealReg << '\t' << Error << endl;
    }
  
  mpL2_RegError *= step;
  L2_RegError = dble(mpL2_RegError);
  cout << "L2-RegError = " << L2_RegError << endl; 
  cout << '\v';
(ostream&) lout <<  "b = " << bd << '\t' <<  " : L2-RegError = " << L2_RegError << endl; 
  
  }
  cout << " *** End: Regularisation *** " << endl;
  

  return 0;
}


