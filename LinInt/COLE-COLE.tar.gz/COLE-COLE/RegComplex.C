#include <unistd.h>    
#include <iomanip.h>      // Formtierung Input/Output
#include <fstream.h>      // Einlesen/Schreiben in Files
#include <iostream.h>     // Input/Output-Operationen
#include <math.h>         // Default Mathematik-Bibliothek
//#include "nrutil.h"     //NRC Utilities
#include "tnumarray.h"    //DOLIB TemplatArrays :-)
#include "tarray.h"       //DOLIB DoubleArrayx :-)
#include "mpmod.H"        // multiprecision Bibliothek
#include "error.h"        //Fehlerroutine DOLIB     :-)
#include "vtype.h"
#include "functionc.H"
#include "datac.H"
#include "interpol.H"

int main()
{
  const DComplex DCI = DComplex(0.0,1.0); 
  cout  << setiosflags(ios::uppercase);

  /* AUSGABEDATEIEN */
  //  ofstream dout("DATA.out");
  //  dout << setiosflags(ios::uppercase);

  ofstream d1out("DATAC_E1.out");
  d1out << setiosflags(ios::uppercase);

  ofstream d2out("DATAC_E2.out");
  d2out << setiosflags(ios::uppercase);
  
  int controll_write_kernel;
  /*
  ofstream kout("KERN.out");
  kout << setiosflags(ios::uppercase);
  */
  ofstream d1intout("DATACE1LIP.out");
  d1intout << setiosflags(ios::uppercase);

  ofstream d2intout("DATACE2LIP.out");
  d2intout << setiosflags(ios::uppercase);

  ofstream lout("L2-ERROR.out");
  lout << setiosflags(ios::uppercase);

  ofstream rout("REG_COMPLEX.out");
  rout << setiosflags(ios::uppercase);

  ofstream wout("WARNINGS.out");
  wout << setiosflags(ios::uppercase);
    
  /* ------------------------------------------ */

  /* Multiprecisionbibliothek initialisieren */
  mp_init();
  mp_real pi  = mppic; // pi aus der Bibliothek !!!
  mp_real pi2 = mppic * mppic;

  static double  dpi = 4.0 * atan(1.0); // pi als double 
  
  static mp_complex I = mp_complex(0.0,1.0);
  
  cout << "*** Precision = " << mpipl << " ***" << endl;
  cout << '\v';
  /* PARAMTER */
  /* Regularisierungsparameter */
  double db;
  mp_real b;
  
  /* Paramter der Regularisierung (Integration)*/
  int M;               // Zahl der St�tzstellen
  double x1, x2;       //Anfangs-/Endpunkt
  mp_real mpx1, mpx2;
  static mp_real mpstepreg; //Schrittweite
  static mp_real factor;            //Vorfaktor des Regularisierungkerns
  
  
  /* Datenparameter, Real- und Imaginaerteil sein diesbezueglich gleich */
  int MD; //Zahl der Daten
  double xa, xb; //Anfang-/Endpunkt der Daten
  double h;  //Datenschrittweite

  /* Intervall und Zahl der Datenpunkte der Regularisierten */
  int N; //Zahl der Datenpunkte 
  double xr1, xr2;  //Anfang- und Endpunkte des Intervalls
  
  cin >> controll_write_kernel;
  cin >> db;
  cin >> xa >> xb >> MD;
  cin >> x1 >> x2 >> M;
  cin >> xr1 >> xr2 >> N;
  
  /*Konversionen double -> mp_real */

  mpx1 = mp_real(x1);
  mpx2 = mp_real(x2);
  b    = mp_real(db);

  /* Berechnung weiterer Paramter */
  /* Schrittweite der Integration in der Regularisierung */
  mpstepreg =(mpx2 - mpx1)/mp_real(M);
  double stepreg = dble(mpstepreg); //Double-Version von mpstepreg

  /* Schrittweite der Regularisierten */
  double step2 = (xr2 - xr1)/N;

  
  /* ------------------------------------------------------ */

  /* REGULARISIERUNGSKERN */

   /* Kernelarray */
  ARRAY<mp_complex> mpregkern(M+1); 

  double Realregkern, Imaregkern;
  
  /*Vorfaktor des Kerns berechnen */
  factor = b/power(pi,mp_real(1.5))*exp(mp_real(1.25)*pi2*b*b);
  
  /* KERNELARRAYs auffuellen */

  cout << "*** Begin: Init. Kernelarrays ***" << endl;

  cout << "db = " << db  << endl;
  cout << "b  = " <<  b ;
  cout << "x1  = " << x1 << endl;  /* Anfangs-/Endpunkt der Regularisierung */
  cout << "x2  = " << x2 << endl;
  cout << "M   = " << M  << endl; 
  cout << "h   = " << mpstepreg;
  cout << "Factor  = " << factor ;
 
  
  mp_real mpx;
  
  for(int i = 0; i <= M; i++) 
    {
      mpx = mpx1 + i * mpstepreg;
      mpregkern[i] = mpcregkern(mpx,b);
    }

  cout << "*** End: Init. Kernelarrays *** " << endl;
  cout <<'\v';

  /* Kontrolle: Regularisierungskern ausgeben */
  
  if(controll_write_kernel == 1)
    {
      ofstream kout("CKERN.out");
      kout << setiosflags(ios::uppercase);
      mp_complex regkern;
      cout <<"*** Begin: Write Regularisationkernel ***" << endl;
        for(int i = 0; i <= M; i++)
	{
	  mpx = mpx1 + i * mpstepreg;
	  regkern = mpcregkern(mpx,b);
	  Realregkern = dble(MP_REAL(mpregkern[i]));
	  Imaregkern  = dble(aimag(mpregkern[i]));
	  mp_real controllkernel = abs(regkern - mpregkern[i]);
	  if(controllkernel != mp_real(0.0)) error("Mismatch: Kernel and Kernelarray");  
	  kout << dble(mpx) << '\t' << Realregkern << '\t' << Imaregkern << '\t' << db<< endl;
	}
      cout <<"*** End:   Write Regularisationkernel ***" << endl;
    }
  
  cout << '\v';
  /* ------------------------------------------------ */
  /* DATEN */
  /* Deklaration, Definition der Datenarrays */
  NUMARRAY<double> datae1(MD,1); /* Daten Realteil */
  NUMARRAY<double> datae2(MD,1); /* Date Imaginaerteil */
  NUMARRAY<double> x(MD,1);      /* x-Vektor, "Frequenzen"*/
  NUMARRAY<double> y2de1(MD,1); /* Vektor der lin. Interpolation des Realt. */
  NUMARRAY<double> y2de2(MD,1); /* Vektor der lin. Interpolation des Imagt. */
  
  h = (xb - xa)/(MD -1);
  double rho = MD/(xb -xa);

  cout << "*** Begin: Init. Data-Array ***" << endl;
  cout << "xa  = " << xa << endl;   /* Anfangs-/Endpunkte der Daten */
  cout << "xb  = " << xb << endl;
  cout << "MD  = " << MD  << endl;  /* Zahl der Datenpunkte */
  cout << "h   = " << h  << endl;
  cout << "rho = " << rho  << endl;
  
  x[1] = xa;
  datae1[1] = real(edata(xa));
  datae2[1] = imag(edata(xa));
  
    for(int i = 2; i <= MD ; i++)
    {
      x[i] = xa + (i-1) * h;
      datae1[i] = real(edata(x[i]));
      datae2[i] = imag(edata(x[i]));
    }

  x[MD] = xb;
  datae1[1] = real(edata(xa));
  datae2[1] = imag(edata(xa));
  cout << "*** End: Init. Data-Array ***" << endl;
  cout << '\v' ;
  
  double RealDataExakt, ImaDataExakt;
  double DataErrore1, DataErrore2; //Relativer Datenfehler

  /* Kontrollausgabe, Datenausgabe */
  for(int i = 1; i <= MD; i++)
    {
      RealDataExakt = real(edata_exakt(x[i]));
      ImaDataExakt  = imag(edata_exakt(x[i]));
      DataErrore1 = fabs(datae1[i] - RealDataExakt)/fabs(RealDataExakt);
      DataErrore1 *= 100.0;

      DataErrore2 = fabs(datae2[i] - ImaDataExakt)/fabs(ImaDataExakt);
      DataErrore2 *= 100.0;


      d1out << i << '\t' << x[i] << '\t' << datae1[i] << '\t' << RealDataExakt << '\t' << DataErrore1 << endl;
      d2out << i << '\t' << x[i] << '\t' << datae2[i] << '\t' << ImaDataExakt << '\t' << DataErrore2 << endl;
    }

  /* INTERPOLATION der Daten */

  double datae1linpol, datae2linpol; //interpolierte Real-/Imag. - Daten
  DComplex datalinpol; //interp. komplexe Daten
  double step, x0;
  double E1, E2 , ErrorrelE1, ErrorrelE2;
  double L2_ErrorE1 = 0.0; 
  double L2_ErrorE2 = 0.0;
  double L2_Error   = 0.0;
  
  cout << "*** Begin: Interpol. *** " << endl;

  /* Realteildaten interpolieren */
  intlinear(x,datae1,MD,y2de1);

  /* Imaginaerteildaten interpolieren */
  intlinear(x,datae2,MD,y2de2);
  
  //  for(int i = 1; i <= MD; i++) outs << i << '\t'  << y2de1[i] << '\t' << y2de2[i] << endl;
 
  /* Kontrollasugaben und Berechnung des Fehlers in der L2-Norm */
  cout << "*** Write interpoled Data ***" << endl;
  
  for(int j = 0; j <= M; j++)
    {
      step = dble(mpstepreg);
      x0 = x1 + j * step;

      datae1linpol = linint(x,datae1,y2de1,MD,x0);
      datae2linpol = linint(x,datae2,y2de2,MD,x0);
      
      E1 = real(edata_exakt(x0));
      E2 = imag(edata_exakt(x0));

      ErrorrelE1 = fabs(datae1linpol - E1)/fabs(E1);
      ErrorrelE1 *= 100.0; // Relativfehler der interpolierten E1
      
      /* Berechnung: L2-Fehler der interpolierten E1 */
      L2_ErrorE1 += (datae1linpol - E1) * (datae1linpol - E1);

      ErrorrelE2 = fabs(datae2linpol - E2)/fabs(E2);
      ErrorrelE2 *= 100.0; // Realtivfehler der interpolierten e2
      
      /* Berechnung: L2-Fehler der interpolierten E2 */
      L2_ErrorE2 += (datae2linpol - E2) * (datae2linpol - E2);
      

      /* Berechnung: L2-Fehler der intep. komplexen Daten */
      datalinpol = datae1linpol+DCI*datae2linpol;
      L2_Error += abs((datalinpol - edata_exakt(x0))*(datalinpol - edata_exakt(x0)));
      

      d1intout << x0 << '\t' << datae1linpol << '\t' << E1 << '\t'<< ErrorrelE1<< endl;

      d2intout << x0 << '\t' << datae2linpol << '\t' << E2 << '\t'<< ErrorrelE2<< endl;
    }

  L2_ErrorE1 *= step;
  L2_ErrorE2 *= step;
  L2_Error   *= step;

  cout << "*** End: Interpol. *** " << endl;
  cout << '\v';
  cout << "*** L2-Error E1 = " << L2_ErrorE1 << " ***" << endl;
  cout << "*** L2-Error E2 = " << L2_ErrorE2 << " ***" << endl;
  cout << "*** L2-Error E  = " << L2_Error   << " ***" << endl;
  cout << '\v';

  /* Die REGULARISIERUNGSROUTINE */
  mp_complex mpreg, mpcdata;
  mp_real mpregtheo, mpRegRelError, mpL2_RegError;
  double reg, regima, regtheo, RegRelError, L2_RegError;

  cout <<"*** Begin: Regularisation ***" << endl;
  cout << "b  = " << db  << endl;
  cout << "b  = " <<  b ;
  cout << "x1 = " << xr1 << endl;
  cout << "x2 = " << xr2 << endl;
  cout << "N  = " << N  << endl;
  cout << "h  = " << step2 << endl;
  cout << '\v' ;
  cout << "Factor  = " << factor ;
  cout << '\v';
  
  /* L2-Norm des Datenfehlereinflusses */
  mpL2_RegError = mp_real(0.0);

  double xi;
  for(int jj = 0; jj <= N; jj++)
    {
      mpreg = mp_complex(0.0,0.0);
      x0 = xr1 + jj * step2;
      
      if(fabs(x0-x1) > fabs(xa)) wout <<"For x0 = " << x0 << endl;
      if(fabs(x0-x2) > fabs(xb)) wout <<"For x0 = " << x0 << endl;

      for(int j = 0; j <= M; j++)
	{
	  xi = x1 + j * stepreg;
	  xi = x0 - xi ;
	  //	  if (xi < xa) error("*** xi out of lowest samplepoint ***");
	  //	  if (xi > xb) error("*** xi out of upper samplepoint ***");
	  datae1linpol = linint(x,datae1,y2de1,MD,xi);
	  datae2linpol = linint(x,datae2,y2de2,MD,xi);
	  mpcdata = mp_complex(datae1linpol,datae2linpol);
	  
	  mpreg += mpregkern[j]*mpcdata;
	}
      
      mpreg *= mpstepreg * factor;

      
      mpregtheo = Regtheo(mp_real(x0),b);
      mpRegRelError = abs(mpreg - mpregtheo)/abs(mpregtheo);
      mpRegRelError *= mp_real(100.0);
  
      mpL2_RegError += abs((mpreg - mpregtheo)*(mpreg - mpregtheo));
    
      cout << mp_real(x0) << mpreg << endl;
      cout << mpregtheo << mpRegRelError << endl;
      
      /* Konversion */
      reg = dble(MP_REAL(mpreg));
      regima = dble(aimag(mpreg));
      regtheo = dble(mpregtheo);
      RegRelError = dble(mpRegRelError);
      rout << x0 << '\t' << regtheo << '\t' << reg << '\t' << regima << '\t' << RegRelError << '\t' << db << endl;
      
    }
  
  mpL2_RegError *= step2;
  L2_RegError = dble(mpL2_RegError);
  
  double L2asymp = UpperBound(L2_Error,db);
  cout << '\v';
  cout << "*** L2-Error E1  = " << L2_ErrorE1 << " ***" << endl;
  cout << "*** L2-Error E2  = " << L2_ErrorE2 << " ***" << endl;
  cout << "*** L2-Error E   = " << L2_Error   << " ***" << endl;
  cout << "*** L2-Regerror  = " << L2_RegError <<" ***" << endl;
  cout << "*** asymp. Error = " << L2asymp     <<" ***" << endl;  

  lout << "L2-Error" << '\t' << "L2-Regerror" <<'\t' << "asymp. Error" <<  endl;  
  lout << L2_Error << '\t' << L2_RegError  << '\t' << L2asymp <<  endl;  
  lout << " " << endl;
  lout << "L2-Error E1" << '\t' << "L2-Error E2" << endl;
  lout << L2_ErrorE1  << '\t' << L2_ErrorE2 << endl;



  return 0;
}


