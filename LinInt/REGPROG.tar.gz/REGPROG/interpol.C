#include <math.h>
#include "interpol.H"
#include "error.h"
//#include "vtype.h"
//#include "tnumarray.h"

void intlinear(NUMARRAY<double> &x, NUMARRAY<double> &y, int n, NUMARRAY<double> &y2)
{
  double h;
  for(int i = 1; i < n; i++)
    {
      h = x[i+1] - x[i];
      if (h == 0.0) error("Bad x input to routine intlinear");    
      y2[i] = (y[i+1] - y[i])/h;
    }
}


double linint(NUMARRAY<double> &xa, NUMARRAY<double> &ya, NUMARRAY<double> &y2a, int n, double x)
{
  int klo,khi,k;
  double h,y;
  
  klo=1;
  khi=n;
  while (khi-klo > 1) {
    k=(khi+klo) >> 1;
    if (xa[k] > x) khi=k;
    else klo=k;
  }
  h=xa[khi]-xa[klo];
  if (h == 0.0) error("Bad xa input to routine linint");

  y = ya[klo] + y2a[klo] * (x - xa[klo]) ;
  
  return y;
}

