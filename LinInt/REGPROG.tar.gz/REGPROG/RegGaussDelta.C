#include <unistd.h>    
#include <iomanip.h>      // Formtierung Input/Output
#include <fstream.h>      // Einlesen/Schreiben in Files
#include <iostream.h>     // Input/Output-Operationen
#include <math.h>         // Default Mathematik-Bibliothek
//#include "nrutil.h"     //NRC Utilities
#include "tnumarray.h"    //DOLIB TemplatArrays :-)
#include "tarray.h"       //DOLIB DoubleArrayx :-)
#include "mpmod.H"        // multiprecision Bibliothek
#include "functionr.H"
#include "data.H"
#include "interpol.H"
#include "random.H"
#include "error.h"        //Fehlerroutine DOLIB     :-)
#include "vtype.h"
#include "qc_utilities.H"

int main()
{
  cout  << setiosflags(ios::uppercase);

  ofstream kout("KERNEL.out");
  kout << setiosflags(ios::uppercase);

  ofstream pout("PARAMETER.out");
  pout << setiosflags(ios::uppercase);

  //  ofstream d1out("DATA_E1.out");
  //  d1out << setiosflags(ios::uppercase);

  //  ofstream d2out("DATA_E2.out");
  //  d2out << setiosflags(ios::uppercase);
  
  ofstream outs("Y2DS.out");
  outs  << setiosflags(ios::uppercase);

  ofstream d1intout("DATAE1LIP.out");
  d1intout << setiosflags(ios::uppercase);

  ofstream d2intout("DATAE2LIP.out");
  d2intout << setiosflags(ios::uppercase);

  //  ofstream l2out("L2-ERROR.out");
  //  l2out << setiosflags(ios::uppercase);

  // ofstream r1out("REGE1.out");
  //  r1out << setiosflags(ios::uppercase);
 
  //  ofstream r2out("REGE2.out");
  //  r2out << setiosflags(ios::uppercase);

  //  ofstream mout("REGM.out");
  //  mout << setiosflags(ios::uppercase);
 
  /* Multiprecisionbibliothek initialisieren */
  mp_init();
  mp_real pi = mppic; // pi aus der Bibliothek !!!
  mp_real pi2 = pi * pi;

  static double  dpi = 4.0 * atan(1.0); // pi als double 

  cout << "*** Precision = " << mpipl << " ***" << endl;
  pout << "MP-Precision = " << mpipl << endl;
  
  /* PARAMTER */
  /* Regularisierungsparameter */
  double db1, db2, db;
  mp_real b1, b2, b, mpbstep;
  int Nb;

  /* Paramter der Regularisierung (Integration)*/
  int M;               // Zahl der St�tzstellen

  double x1, x2;       //Anfangs-/Endpunkt
  mp_real mpx1, mpx2;
  static mp_real mpstepreg; //Schrittweite

  /* Datenparameter, Real- und Imaginaerteil sein diesbezueglich gleich */
  int MD; //Zahl der Daten
  double xa, xb; //Anfang-/Endpunkt der Daten
  double h;  //Datenschrittweite
  double nu; //Nouislevel

  /* Intervall und Zahl der Datenpunkte der Regularisierten */
  int N; //Zahl der Datenpunkte 
  double xr1, xr2;  //Anfang- und Endpunkte des Intervalls
  

  /* Parameter einlesen */
  cin >> db1 >> db2 >> Nb;
  cin >> xa >> xb >> MD >> nu;
  cin >> x1 >> x2 >> M;  
  cin >> xr1 >> xr2 >> N;

  /* Konversionen der Parameter: double -> mp_real */
  mpx1 = mp_real(x1);
  mpx2 = mp_real(x2);
  b1    = mp_real(db1);
  b2    = mp_real(db2);
  cout << "+++ Konversion beendet +++" << endl;

  /* Berechnung weiterer Paramter */
  /* Schrittweite der Integration in der Regularisierung */
  mpstepreg = (mpx2 - mpx1)/mp_real(M);  

  /* Schrittweite der Regularisierten */
  double step2 = (xr2 - xr1)/N;

  /* Schrittweite RegScan */
  if(Nb==0) mpbstep = mp_real(0.0);
  else mpbstep = (b2 - b1)/mp_real(Nb);


  /* Dateien - part 2 Anfang */

  String data1 = "DATA_E1-MD";
  data1 = data1 + strdup(fix3(MD)) + "-xb" + strdup(fix3(xb)) + ".out";;
  ofstream d1out(data1());
  d1out << setiosflags(ios::uppercase);

  String data2 = "DATA_E2-MD";
  data2 = data2 +  strdup(fix3(MD)) + "-xb" + strdup(fix3(xb)) + ".out";
  ofstream d2out(data2());
  d2out << setiosflags(ios::uppercase);
    /* Dateien - part 2 Ende */

  String l2 = "L2-ERROR-MD";
  l2 = l2 + strdup(fix3(MD)) + "-xb" + strdup(fix3(xb)) + "-Nb" + strdup(fix3(Nb)) + "-b1:" + strdup(fix3(db1)) + "-b2:" + strdup(fix3(db2)) + ".out"; 
  ofstream l2out(l2());
  l2out << setiosflags(ios::uppercase);

  cout <<"+++ Dateien mit Parametern angelegt +++" << endl;

  /* ---------------------------------------------------*/

    /* ------------------------------------------------------ */

  /* DATEN */
  /* Deklaration, Definition der Datenarrays */
  NUMARRAY<double> datae1(MD,1); /* Daten Realteil */
  NUMARRAY<double> datae2(MD,1); /* Date Imaginaerteil */
  NUMARRAY<double> x(MD,1);      /* x-Vektor, "Frequenzen"*/
  NUMARRAY<double> y2de1(MD,1); /* Vektor der lin. Interpolation des Realt. */
  NUMARRAY<double> y2de2(MD,1); /* Vektor der lin. Interpolation des Imagt. */
  
  h = (xb - xa)/(MD -1);
  double rho = MD/(xb -xa);

  cout << "*** Begin: Init. Data-Array ***" << endl;
  cout << "xa  = " << xa << endl;   /* Anfangs-/Endpunkte der Daten */
  cout << "xb  = " << xb << endl;
  cout << "MD  = " << MD  << endl;  /* Zahl der Datenpunkte */
  cout << "h   = " << h  << endl;
  cout << "nu  = " << nu << endl;
  cout << "rho = " << rho  << endl;
 
  pout << "*** Parameter der gen. Daten ***" << endl;
  pout << "Intervall Anfang: xa = " << xa << endl;  
  pout << "Intervall Ende: xb   = " << xb << endl;
  pout << "Datenanzahl:    MD   = " << MD  << endl;  /* Zahl der Datenpunkte */
  pout << "Noislevel:      nu   = " << nu << endl;
  pout << "Schrittweite:   h    = " << h  << endl;
  pout << "Datendichte:    rho  = " << rho  << endl;
  
  x[1] = xa;
  datae1[1] = e1data(xa,nu);
  datae2[1] = e2data(xa,nu);
  
  for(int i = 2; i <= MD ; i++)
    {
      x[i] = xa + (i-1) * h;
      datae1[i] = e1data(x[i],nu);
      datae2[i] = e2data(x[i],nu);
    }

  x[MD] = xb;
  datae1[MD] = e1data(xb,nu);
  datae2[MD] = e2data(xb,nu);
  
  cout << "*** End: Init. Data-Array ***" << endl;
  cout << '\v' ;
  
  double DataErrore1, DataErrore2; //Relativer Datenfehler

  /* Kontrollausgabe, Datenausgabe */
  for(int i = 1; i <= MD; i++)
    {
      DataErrore1 = fabs(datae1[i] - e1data_exakt(x[i]))/fabs(e1data_exakt(x[i]));
      DataErrore1 *= 100.0;

      DataErrore2 = fabs(datae2[i] - e2data_exakt(x[i]))/fabs(e2data_exakt(x[i]));
      DataErrore2 *= 100.0;


      d1out << i << '\t' << x[i] << '\t' << datae1[i] << '\t' << e1data_exakt(x[i]) << '\t' << DataErrore1 << endl;
      d2out << i << '\t' << x[i] << '\t' << datae2[i] << '\t' << e2data_exakt(x[i]) << '\t' << DataErrore2 << endl;
    }

  /* INTERPOLATION der Daten */

  double datae1linpol, datae2linpol; //interpolierte Real-/Imag. - Daten
  double step, x0;
  double E1, E2 , ErrorrelE1, ErrorrelE2;
  double L2_ErrorE1 = 0.0; 
  double L2_ErrorE2 = 0.0;
  
  cout << "*** Begin: Interpol. *** " << endl;

  /* Realteildaten interpolieren */
  intlinear(x,datae1,MD,y2de1);

  /* Imaginaerteildaten interpolieren */
  intlinear(x,datae2,MD,y2de2);
  
  for(int i = 1; i <= MD; i++) outs << i << '\t'  << y2de1[i] << '\t' << y2de2[i] << endl;
 
  /* Kontrollasugaben und Berechnung des Fehlers in der L2-Norm */

  
  for(int j = 0; j <= M; j++)
    {
      step = dble(mpstepreg);
      x0 = x1 + j * step;

      datae1linpol = linint(x,datae1,y2de1,MD,x0);
      datae2linpol = linint(x,datae2,y2de2,MD,x0);
      
      E1 = e1data_exakt(x0);
      E2 = e2data_exakt(x0);

      ErrorrelE1 = fabs(datae1linpol - E1)/fabs(E1);
      ErrorrelE1 *= 100.0; // Relativfehler der interpolierten E1
      
      /* Berechnung: L2-Fehler der interpolierten E1 */
      L2_ErrorE1 += (datae1linpol - E1) * (datae1linpol - E1);

      ErrorrelE2 = fabs(datae2linpol - E2)/fabs(E2);
      ErrorrelE2 *= 100.0; // Realtivfehler der interpolierten e2
      
      /* Berechnung: L2-Fehler der interpolierten E2 */
      L2_ErrorE2 += (datae2linpol - E2) * (datae2linpol - E2);
      
      
      d1intout << x0 << '\t' << datae1linpol << '\t' << E1 << '\t'<< ErrorrelE1<< endl;

      d2intout << x0 << '\t' << datae2linpol << '\t' << E2 << '\t'<< ErrorrelE2<< endl;
    }

  L2_ErrorE1 *= step;
  L2_ErrorE2 *= step;

  cout << "*** End: Interpol. *** " << endl;
  cout << '\v';
  cout << "*** L2-Error E1 = " << L2_ErrorE1 << " ***" << endl;
  cout << "*** L2-Error E2 = " << L2_ErrorE2 << " ***" << endl;
  cout << '\v';

  /* ------------------------------------------------------*/

  /* *** REGULARISIERUNGSSCAN *** */

  /* *** Regularisierungskerne und deren Vorfaktoren *** */

  /*  Deklarationen */
  static mp_real factorE1;
  static mp_real factorE2;
  mp_real mpx;
  //  static double dfactore1;
  //  static double dfactore2;
  
  NUMARRAY<mp_real> mpregKernE1(M+1);
  NUMARRAY<mp_real> mpregKernE2(M+1);

  
  cout << "*** Begin: Regularisationscan *** " << endl;
  cout << "db1 = " << db1  << endl;
  cout << "b1  = " <<  b1 ;
  cout << "db2 = " << db2  << endl;
  cout << "b2  = " <<  b2 ;
  cout << "bh  = " << mpbstep;
  cout << "x1  = " << x1 << endl;  /* Anfangs-/Endpunkt der Regularisierung */
  cout << "x2  = " << x2 << endl;
  cout << "M   = " << M  << endl; 
  cout << "h   = " << mpstepreg;

  cout << '\v' ;

  cout <<"*** Parameter der Regularisierten ***" << endl;
  cout << "Intervall Anfang: x1 = " << xr1 << endl;
  cout << "Intervall Ende: x2   = " << xr2 << endl;
  cout << "# der Datenpunkte N  = " << N  << endl;
  cout << "Schrittweite      h  = " << step2 << endl;
  cout << "Dichte          rho  = " << 1/step2 << endl;

  
  pout << "*** Parameter der Regularisierungsroutine***" << endl;
  pout << "db1       = " << db1  << endl;
  pout << "db2       = " << db2  << endl;
  pout << "Nb        = " << Nb << endl;
  pout << "hb        = " << dble(mpbstep)  << endl;
  //pout << "FactorE1  = " << factorE1 ;
  //pout << "FactorE2  = " << factorE2 ;

  pout << "Intergation Anfang: x1  = " << x1 << endl; 
  pout << "Integration Ende:   x2  = " << x2 << endl;
  pout << "St�tzstellen        M   = " << M  << endl; 
  pout << "Schrittweite        h   = " << dble(mpstepreg) << endl;


  pout <<"*** Parameter der Regularisierten ***" << endl;
  pout << "Intervall Anfang: x1 = " << xr1 << endl;
  pout << "Intervall Ende: x2   = " << xr2 << endl;
  pout << "# der Datenpunkte N  = " << N  << endl;
  pout << "Schrittweite      h  = " << step2 << endl;
  pout << "Dichte          rho  = " << 1/step2 << endl;

  cout << '\v';

  for(int jj = 0; jj <= Nb; jj++)
  {

      b = b1 + jj*mpbstep;
      db = dble(b);
      
      cout << "*** j = " << jj << ", b = " << db << " ***" << endl;  
      cout << '\v';

  /* Dateien Part 3 Anfang */
  
  String regdatei1 = "REGE1-MD";
  regdatei1 = regdatei1 + strdup(fix3(MD)) + "-xb" + strdup(fix3(xb)) + "-b" + strdup(fix3(db)) + ".out";
  ofstream r1out(regdatei1());
  r1out << setiosflags(ios::uppercase);
 
  String regdatei2 = "REGE2-MD";
  regdatei2 = regdatei2 + strdup(fix3(MD)) + "-xb" + strdup(fix3(xb)) + "-b" + strdup(fix3(db)) + ".out";
  ofstream r2out(regdatei2());
  r1out << setiosflags(ios::uppercase);
  
  String regcdm = "REGM-MD";
  regcdm = regcdm + strdup(fix3(MD)) + "-xb" + strdup(fix3(xb)) + "-b:" + strdup(fix3(db)) + ".out";
  ofstream mout(regcdm());
  mout << setiosflags(ios::uppercase);
  
  
  /* Dateien Part 3 Ende */

  
//  cout <<"+++ MP_KERNE_ARAYS angelegt +++" << endl;
  
  //  D_NumArray<mp_real> mpregKernE1(M+1);
  //  D_NumArray<mp_real> mpregKernE2(M+1);
    
  /* Definition/Berechnung der Vorfaktoren der Regularisierungskerne */
  factorE1 = mp_real(2.0)*b/power(pi,mp_real(1.5));
  factorE1 *= exp(mp_real(0.25) * pi2 * b * b);
  
//  cout <<"+++ FaktorE1 berechnet +++" << endl;

  factorE2 = mp_real(2.0)*b/power(pi,mp_real(1.5));
  factorE2 *= exp(mp_real(0.25) * pi2 * b * b);
  
//  cout <<"+++ FaktorE2 berechnet +++" << endl;
  
  //dfactore1 = 2.0 * (db1/pow(dpi,1.5)) * exp(db1*db1*dpi*dpi*.25);
  //  cout <<"+++ dFaktorE1 berechnet +++" << endl;

  //  dfactore2 = 2.0 * (db2/pow(dpi,1.5)) * exp(db2*db2*dpi*dpi*.25);

  //  cout <<"+++ double FaktorE2 berechnet +++" << endl;
  /* KERNELARRAYs auffuellen */

//  cout << '\v';
  cout << "+++ Begin: Init. Kernelarrays +++" << endl;
  

  cout << "FactorE1  = " << factorE1 ;
  //  cout << "dfactore1 = " << dfactore1 << endl;
  cout << "FactorE2  = " << factorE2 ;
  //  cout << "dfactore2 = " << dfactore2 << endl;
//  cout << '\v';

  for(int i = 0; i <= M; i++) 
    {
      mpx = mpx1 + i * mpstepreg;
      mpregKernE1[i] = mpregkerne1(mpx, b);
      mpregKernE2[i] = mpregkerne2(mpx, b);
    }

  cout << "+++ End: Init. Kernelarrays +++ " << endl;
  cout <<'\v';


  /* TEST !! 
  //  cout << "+++ Kernel Realteil +++" << endl;
  kout << "+++ Kernel Realteil +++" << endl;
  for(int i = 0; i <= M; i++)
    {
      mpx = mpx1 + i * mpstepreg;
      //  cout << mpx << mpregkerne1(mpx,b1) << mpregKernE1[i] << endl;
      
      double x = dble(mpx);
      kout << regkerne1(x,db1)  << '\t' << '\t' << dble( mpregkerne1(mpx,b1)) << '\t' <<  dble(mpregKernE1[i]) << endl;
     }

  //  cout << "+++ Kernel Imagin�rteil +++" << endl;
  kout << "+++ Kernel Imagin�rteil +++" << endl;
  for(int i = 0; i <= M; i++)
    {
      mpx = mpx1 + i * mpstepreg;
      //      cout << mpx << mpregkerne2(mpx,b2) << mpregKernE2[i] << endl;
      
      double x = dble(mpx);
      kout << regkerne2(x,db2)  << '\t' << '\t' << dble(mpregkerne2(mpx,b2)) << '\t' <<  dble(mpregKernE2[i]) << endl;
     }
     TEST !!! */



  /* Die REGULARISIERUNGSROUTINE */
  mp_real mprege1, mprege2, mpe1regtheo, mpe2regtheo;
  double rege1, rege2, e1regtheo, e2regtheo;

  mp_real mpRegRelErrorE1, mpRegRelErrorE2;
  double RegRelErrorE1, RegRelErrorE2;

  /* L2-Norm des Datenfehlereinflusses */
  double  L2rege1, L2rege2;
  mp_real mpL2rege1 = mp_real(0.0);
  mp_real mpL2rege2 = mp_real(0.0);
  
  double mittel1, mittel2;

  cout <<"+++ Begin: Regularisation +++" << endl;


  double xi;
  for(int jj = 0; jj <= N; jj++)
    {
      mprege1 = mp_real(0.0);
      mprege2 = mp_real(0.0);
      x0 = xr1 + jj * step2;
      
      for(int j = 0; j <= M; j++)
	{
	  xi = x1 + j * step;
	  xi = xi - x0;
	  
	  datae1linpol = linint(x,datae1,y2de1,MD,xi);
	  datae2linpol = linint(x,datae2,y2de2,MD,xi);
	  
	  mprege1 += mpregKernE1[j] * mp_real(datae1linpol);
	  mprege2 += mpregKernE2[j] * mp_real(datae2linpol);
	  
	}
      
      mprege1 *= mpstepreg * factorE1;
      mprege2 *= mpstepreg * factorE2;

      mpe1regtheo = Regtheo(mp_real(x0),b);
      mpe2regtheo = Regtheo(mp_real(x0),b);
      
      mpRegRelErrorE1 = abs(mprege1 - mpe1regtheo)/abs(mpe1regtheo);
      mpRegRelErrorE1 *= mp_real(100.0);

      mpRegRelErrorE2 = abs(mprege2 - mpe2regtheo)/abs(mpe2regtheo);
      mpRegRelErrorE2 *= mp_real(100.0);

      mpL2rege1 += (mprege1 - mpe1regtheo) * (mprege1 - mpe1regtheo);
      mpL2rege2 += (mprege2 - mpe2regtheo) * (mprege2 - mpe2regtheo);


      /* Konversionen */

      rege1         = dble(mprege1);
      rege2         = dble(mprege2);
      e1regtheo     = dble(mpe1regtheo);
      e2regtheo     = dble(mpe2regtheo);
      RegRelErrorE1 = dble(mpRegRelErrorE1);
      RegRelErrorE2 = dble(mpRegRelErrorE2);

      mittel1 = .5*(rege1 + rege2);
      mittel2 = sqrt(.5 * (rege1*rege1 + rege2*rege2));

      /*
      cout << x0 << endl;
      cout << mprege1 << mpe1regtheo << mpRegRelErrorE1 << endl;
      cout << mprege2 << mpe2regtheo << mpRegRelErrorE2 << endl;
      */

      r1out << x0 << '\t' << e1regtheo << '\t' << rege1 << '\t' << RegRelErrorE1 <<  endl;
      r2out << x0 << '\t' << e2regtheo << '\t' << rege2 << '\t' << RegRelErrorE2 << endl;

      mout << x0 << '\t' << mittel1  << '\t' << mittel2  << '\t' << e1regtheo << '\t' << e2regtheo << endl;

    }
    
  cout <<"+++ End: Regularisation +++" << endl;
  mpL2rege1 *= step2;
  mpL2rege2 *= step2;
  
  L2rege1 = dble(mpL2rege1);
  L2rege2 = dble(mpL2rege2);

  double a1 = 1.0/(2.0*db);
  double a2 = 1.0/(2.0*db);
  double asympe1 = UpperBound(L2_ErrorE1,a1);
  double asympe2 = UpperBound(L2_ErrorE2,a2);

  cout << '\v';

  cout << "+++ L2-Error E1     = " << L2_ErrorE1 << " +++" << endl;
  cout << "+++ L2-Regerror  E1 = " << L2rege1 << " +++" << endl;
  cout << "+++ asymp. Error E1 = " << asympe1 << " +++" << endl;
  cout << '\v';
  cout << "+++ L2-Error E2     = " << L2_ErrorE2 << " +++" << endl;
  cout << "+++ L2-Regerror  E2 = " << L2rege2 << " +++" << endl;
  cout << "+++ asymp. Error E2 = " << asympe2 << " +++" << endl;  
  cout << '\v';

  l2out << "*** b = " << db << " ***" << endl;  
  l2out << "L2-Error E1     = " << L2_ErrorE1 << endl;
  l2out << "L2-Regerror  E1 = " << L2rege1 << endl;
  l2out << "asymp. Error E1 = " << asympe1 << endl;
  l2out << "L2-Error E2     = " << L2_ErrorE2 << endl;
  l2out << "L2-Regerror  E2 = " << L2rege2 << endl;
  l2out << "asymp. Error E2 = " << asympe2 << endl;  
  
  }  
  cout << "*** End: Regularisationscan *** " << endl;
  
  return 0;
}
