#include <math.h>
#include "random.H"

double e1data(double x, double xi)
{
  double p,q,y,nu;
  nu = Xi1double(x);
  //  xi = 0.0;
  p = 1.0;
  q = 1.0 + exp(- 2.0 * x);
  y = p/q;
  y *= (1.0 + xi * nu);
  return y;
}

double e1data_exakt(double x)
{
  double p,q,y;
  p = 1.0;
  q = 1.0 + exp(- 2.0 * x);
  y = p/q;
  return y;
}

double e2data(double x, double xi)
{
  double p,q,y,nu;
  nu = Xi1double(x);
  //  xi = 0.0;
  p = exp(-x);
  q = 1.0 + exp(- 2.0 * x);
  y = p/q;
  y *= (1.0 + xi * nu);
  return y;
}

double e2data_exakt(double x)
{
  double p,q,y;
  p = exp(-x);
  q = 1.0 + exp(- 2.0 * x);
  y = p/q;
  return y;
}





