#include <math.h>
#include "mpmod.H"
#include <iostream.h>

mp_real mpregkerne1(mp_real x_, mp_real b_)
{
  static mp_real pi = mppic ;
  // cout << "pi = " << pi << endl;
  mp_real _y = exp(-b_ * b_ * x_ * x_ ) * sin(pi * b_ * b_ * x_ );
  return _y;
}

mp_real mpregkerne2(mp_real x_, mp_real b_)
{
  static mp_real pi = mppic ;
  mp_real _y = exp(-b_ * b_ * x_ * x_ ) * cos(pi * b_ * b_ * x_ );
  return _y;
}


mp_real Regtheo(mp_real x_, mp_real b_)
{
  static mp_real Sqrtpi = sqrt(mppic);
  mp_real y_ = b_/Sqrtpi * exp(- b_ * b_ * x_ * x_);
  return y_ ;
}


double UpperBound(double sigma, double gamma)
{
  static double pi = 4.0 * atan(1.0);
  double bound = .5*pow(2.0*pi,1.5) * sigma/gamma * exp(1.2337/(gamma*gamma));
  // double bound = sigma/(sqrt(2.0*pi)*gamma) * exp(0.25/(gamma*gamma));
  return bound;
}

double regkerne1(double x_, double b_)
{
  static double pi = 4.0 * atan(1.0);
  double y = exp(-b_ * b_ * x_ * x_ ) * sin(pi * b_ * b_ * x_ );
  return y;
}

double regkerne2(double x_, double b_)
{
  static double pi = 4.0 * atan(1.0);
  double y = exp(-b_ * b_ * x_ * x_ ) * cos(pi * b_ * b_ * x_ );
  return y;
}
