#include <unistd.h>    
#include <iomanip.h>      // Formtierung Input/Output
#include <fstream.h>      // Einlesen/Schreiben in Files
#include <iostream.h>     // Input/Output-Operationen
#include <math.h>         // Default Mathematik-Bibliothek
#include "mpmod.H"        // multiprecision Bibliothek

//const DComplex I     = DComplex(0.0,1.0);

mp_real Gauss(mp_real x, mp_real b)
{
  //static mp_real Sqrtpi = sqrt(mppic);
  mp_real y = exp(- x*x*b*b);
  return y;
}

mp_real FGauss(mp_real x, mp_real b)
{
  mp_real y = exp(-(mp_real(0.25)*x*x)/(b*b));
  return y;
}

int main()
{
  mp_init();

  const mp_complex I = mp_complex(0.0,1.0);

  static mp_real Sqrtpi = sqrt(mppic);
  
  cout  << setiosflags(ios::uppercase);

  ofstream out("COMPLEX-TEST.out");
  out << setiosflags(ios::uppercase);
  
  int M, N;
  double bd;
  double x1d, x2d, xad, xbd;
  
  cin >> bd;
  cin >> xad >> xbd >> N;
  cin >> x1d >> x2d >> M;

  cout << "b  = " << bd << endl;
  cout << "xa = " << xad << endl;
  cout << "xb = " << xbd << endl;
  cout << "x1 = " << x1d << endl;
  cout << "x2 = " << x2d << endl;
  cout << "N  = " << N << endl;
  cout << "M  = " << M << endl;

  mp_real xa   = mp_real(xad);
  mp_real xb   = mp_real(xbd);
  mp_real x1   = mp_real(x1d);
  mp_real x2   = mp_real(x2d);
  mp_real  b   = mp_real(bd);

  mp_real factor = b/Sqrtpi ;
  cout << "Faktor = " << factor << endl;

  mp_real h    = (xb - xa)/mp_real(N);
  cout << "h  = " << h ;

  mp_real step = (x2 - x1)/mp_real(M);
  cout << "h2 = " << step;
  cout << '\v';

  mp_complex summp;
  // mp_real summp;
  mp_real z;
  mp_real y;
  mp_real RelError;
  
  for(int jj = 0; jj <= M; jj++)
    {
      y = x1 + jj * step;
      summp = mp_real(0.0);
      
      for(int i = 1; i <= N; i++)
	{
	  z = xa + i * h;
	  summp += Gauss(z,b)*(cos(z*y)+ I*sin(z*y));
	  //  summp += Gauss(z,b)* cos(z*y);
	}
      summp *= factor * h;
      // summp *= h;
      
      RelError = abs(summp - FGauss(y,b))/abs(FGauss(y,b));
      cout << y;
      cout << summp << endl;
      cout << FGauss(y,b);
      cout << RelError << endl;
      
      out << dble(y) << '\t' << dble(FGauss(y,b)) << '\t' << dble(MP_REAL(summp)) << '\t' << dble(aimag(summp)) << '\t' << dble(RelError) << '\t' << bd << endl;
    }
    
    
  return 0;
}
