#include <unistd.h>    
#include <iomanip.h>      // Formtierung Input/Output
#include <fstream.h>      // Einlesen/Schreiben in Files
#include <iostream.h>     // Input/Output-Operationen
#include <math.h>         // Default Mathematik-Bibliothek
#include "mpmod.H"        // multiprecision Bibliothek

const DComplex I     = DComplex(0.0,1.0);
const mp_complex Imp = mp_complex(0.0,1.0);
int main()
{
  mp_init();
  
  cout  << setiosflags(ios::uppercase);
  
  ofstream out("COMPLEX-TEST.out");
  out << setiosflags(ios::uppercase);

  ofstream out2("COMPLEX-TEST2.out");
  out2 << setiosflags(ios::uppercase);

  int N;
  double x, xa, xb;

  cin >> xa >> xb >> N;
  double h = (xb - xa)/N;

  DComplex g;
  double g1, g2;

  cout << "*** Complex-DATA Test ***" << endl;

  for(int i = 0; i <= N; i++)
    {
      x = xa + i * h;

      g = 1.0/(1.0 - I * exp(-x));

      //g = 1.0/power((1.0 - power(I * exp(-x),0.9)),0.9);
      //g = 1.0/power((1.0 - I * exp(-x)),.5);
      

      g1 = 1.0/(1.0 + exp(-2.0*x));
      g2 = exp(-x)/(1.0 + exp(-2.0*x));

      cout << x << '\t' << g << endl;

      out <<  x << '\t' << real(g) << '\t' << g1 - real(g) << '\t' << imag(g) << '\t' << g2 - imag(g) << endl;
      
    }

  cout << "*** Complex-Function Test ***" << endl;

  mp_real x2, y, rea, ima;
  mp_complex f;
  
  x2 = mp_real(.5);
  //  x2 = 0.0;
  for(int j = 0; j <= N; j++)
    {

      y = mp_real(xa + j * h);
      rea = exp(x2)*cos(y);
      ima = exp(x2)*sin(y);

      f =  rea + Imp * ima;
      cout << f << endl;

      double dy  = dble(y);
      double dx2 = dble(x2);

      double d_rea1 = exp(dx2)*cos(dy);
      double d_rea2 = dble(MP_REAL(f));

      double d_ima1 = exp(dx2)*sin(dy);
      double d_ima2 = dble(aimag(f));

      out2 << dy <<'\t' << d_rea1 << '\t' << d_rea2 << '\t' << d_ima1 << '\t'  << d_ima2 << endl;
    }
  return 0;
}
