#include <math.h>
#include "mpmod.H"



mp_complex mpregkernc(mp_real x, mp_real x0, mp_real b)
{
  static mp_real pi   = mppic ;
  static mp_real pi2  = mppic*mppic;
  static mp_complex I = mp_complex(0.0,1.0);
  mp_real b2 = b*b;
  
  mp_complex y = exp(-b2*(x0-x)*(x0-x))*(cos(pi*b2*(x0-x))+I*sin(pi*b2*(x0-x)))*(I*cos(2.0*pi*b2*(x0-x))*sinh(pi2*b2)-sin(2.0*pi*b2*(x0-x))*cosh(pi2*b2));

  return y;
}

mp_complex mpcregkern(mp_real x, mp_real b)
{
  static mp_real pi   = mppic ;
  static mp_real pi2  = mppic*mppic;
  static mp_complex I = mp_complex(0.0,1.0);
  mp_real b2 = b*b;
  
  mp_complex y = exp(-b2*x*x)*(cos(pi*b2*x)+I*sin(pi*b2*x))*(I*cos(2.0*pi*b2*x)*sinh(pi2*b2)-sin(2.0*pi*b2*x)*cosh(pi2*b2));

  return y;
}

mp_real Regtheo(mp_real x_, mp_real b_)
{
  static mp_real Sqrtpi = sqrt(mppic);
  mp_real y_ = b_/Sqrtpi * exp(- b_ * b_ * x_ * x_);
  return y_ ;
}


double UpperBound(double sigma, double gamma)
{
  static double pi = 4.0 * atan(1.0);
  // double bound = pow(2.0*pi,1.5) * sigma/gamma * exp(0.25/(gamma*gamma));
  double bound = (1.0/sqrt(2.0*pi)) * sigma/gamma * exp(11.103305/(gamma*gamma));
  // double bound = sigma/(sqrt(2.0*pi)*gamma) * exp(0.25/(gamma*gamma));
  return bound;
}
