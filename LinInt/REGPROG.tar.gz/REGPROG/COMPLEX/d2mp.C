#include <unistd.h>    
#include <iomanip.h>      // Formtierung Input/Output
#include <fstream.h>      // Einlesen/Schreiben in Files
#include <iostream.h>     // Input/Output-Operationen
#include <math.h>         // Default Mathematik-Bibliothek
//#include "nrutil.h"     //NRC Utilities
#include "tnumarray.h"    //DOLIB TemplatArrays :-)
#include "tarray.h"       //DOLIB DoubleArrayx :-)
#include "mpmod.H"        // multiprecision Bibliothek
#include "error.h"        //Fehlerroutine DOLIB     :-)
#include "vtype.h"
#include "functionc.H"
#include "datac.H"
#include "vtype.h"
#include "qc_utilities.H"

//#include "interpol.H"

int main()
{
  //  const DComplex DCI = DComplex(0.0,1.0); 
  cout  << setiosflags(ios::uppercase);

  /* AUSGABEDATEIEN */
  /*
  ofstream dout("DATAd2mp.out");
  dout << setiosflags(ios::uppercase);

  ofstream lout("L2-D2MP-ERROR.out");
  lout << setiosflags(ios::uppercase);

  ofstream rout("D2MP.out");
  rout << setiosflags(ios::uppercase);
  */

  ofstream wout("D2MPWarnings.out");
  wout << setiosflags(ios::uppercase);
    
  /* ------------------------------------------ */

  /* Multiprecisionbibliothek initialisieren */
  mp_init();
  mp_real pi  = mppic; // pi aus der Bibliothek !!!
  mp_real pi2 = mppic * mppic;

  static double  dpi = 4.0 * atan(1.0); // pi als double 
  
  static mp_complex I = mp_complex(0.0,1.0);
  
  cout << "*** Precision = " << mpipl << " ***" << endl;
  cout << '\v';
  /* PARAMTER */
  /* Regularisierungsparameter */
  double db;
  mp_real b;
  
  /* Paramter der Regularisierung (Integration)*/
  int M;               // Zahl der St�tzstellen
  double x1, x2;       //Anfangs-/Endpunkt
  mp_real mpx1, mpx2;
  static mp_real mpstepreg; //Schrittweite
  static mp_real factor;            //Vorfaktor des Regularisierungkerns
  
  
  /* Datenparameter, Real- und Imaginaerteil sein diesbezueglich gleich */
  int MD; //Zahl der Daten
  double xa, xb; //Anfang-/Endpunkt der Daten
  //  double h;  //Datenschrittweite

  /* Intervall und Zahl der Datenpunkte der Regularisierten */
  int N; //Zahl der Datenpunkte 
  double xr1, xr2;  //Anfang- und Endpunkte des Intervalls
  int controll_write_kernel;
  
  cin >> controll_write_kernel;
  cin >> db;
  cin >> xa >> xb >> MD;
  cin >> x1 >> x2 >> M;
  cin >> xr1 >> xr2 >> N;
  
  /*Konversionen double -> mp_real */

  mpx1 = mp_real(x1);
  mpx2 = mp_real(x2);
  b    = mp_real(db);

  /* Berechnung weiterer Paramter */
  /* Schrittweite der Integration in der Regularisierung */
  mpstepreg =(mpx2 - mpx1)/mp_real(M);
  double stepreg = dble(mpstepreg); //Double-Version von mpstepreg

  /* Schrittweite der Regularisierten */
  double step2 = (xr2 - xr1)/N;


  /* Dateien */
  String data2 = "DATA2MP-MD";
  data2 = data2 + M + "-xb" + x2 + ".out";
  ofstream dout(data2());
  dout << setiosflags(ios::uppercase);

  String regdatei2 = "D2MP-MD";
  regdatei2 = regdatei2 + strdup(fix3(M)) + "-xb" + x2 + "-b" + strdup(fix3(db)) + ".out";
  ofstream rout(regdatei2());
  rout << setiosflags(ios::uppercase);

  String l2 = "L2-D2MP-ERROR-MD";
  l2 = l2 + M + "-xb" + x2 + "-b" + strdup(fix3(db)) +".out";
  ofstream lout(l2());
  lout << setiosflags(ios::uppercase);


  
  /* ------------------------------------------------------ */

  /* REGULARISIERUNGSKERN */

   /* Kernelarray */
  ARRAY<mp_complex> mpregkern(M+1); 

  double Realregkern, Imaregkern;
  
  /*Vorfaktor des Kerns berechnen */
  factor = b/power(pi,mp_real(1.5))*exp(mp_real(1.25)*pi2*b*b);
  
  /* KERNELARRAYs auffuellen */

  cout << "*** Begin: Init. Kernelarrays ***" << endl;

  cout << "db = " << db  << endl;
  cout << "b  = " <<  b ;
  cout << "x1  = " << x1 << endl;  /* Anfangs-/Endpunkt der Regularisierung */
  cout << "x2  = " << x2 << endl;
  cout << "M   = " << M  << endl; 
  cout << "h   = " << mpstepreg;
  cout << "Factor  = " << factor ;
 
  
  mp_real mpx;
  
  for(int i = 0; i <= M; i++) 
    {
      mpx = mpx1 + i * mpstepreg;
      mpregkern[i] = mpcregkern(mpx,b);
    }

  cout << "*** End: Init. Kernelarrays *** " << endl;
  cout <<'\v';

  /* Kontrolle: Regularisierungskern ausgeben */
  
  if(controll_write_kernel == 1)
    {
      ofstream kout("CKERN.out");
      kout << setiosflags(ios::uppercase);
      mp_complex regkern;
      cout <<"*** Begin: Write Regularisationkernel ***" << endl;
        for(int i = 0; i <= M; i++)
	{
	  mpx = mpx1 + i * mpstepreg;
	  regkern = mpcregkern(mpx,b);
	  Realregkern = dble(MP_REAL(mpregkern[i]));
	  Imaregkern  = dble(aimag(mpregkern[i]));
	  mp_real controllkernel = abs(regkern - mpregkern[i]);
	  if(controllkernel != mp_real(0.0)) error("Mismatch: Kernel and Kernelarray");  
	  kout << dble(mpx) << '\t' << Realregkern << '\t' << Imaregkern << '\t' << db<< endl;
	}
      cout <<"*** End:   Write Regularisationkernel ***" << endl;
    }
  
  cout << '\v';
  /* ------------------------------------------------ */
  /* DATEN */

  cout << "*** Write Data ***" << endl;
  double datae1linpol, datae2linpol;  
  double x0,xi;

  for(int j = 0; j <= M; j++)
    {
      x0 = x1 + j * stepreg;

      datae1linpol = real(edata_exakt(x0));
      datae2linpol = imag(edata_exakt(x0));
            

      dout << x0 << '\t' << datae1linpol << '\t' << datae2linpol << endl;

    }
  cout << "*** End: Data ***" << endl;
  

  /* Die REGULARISIERUNGSROUTINE */
  mp_complex mpreg, mpcdata;
  mp_real mpregtheo, mpRegRelError, mpL2_RegError;
  double reg, regima, regtheo, RegRelError, L2_RegError;

  cout <<"*** Begin: Regularisation ***" << endl;
  cout << "b  = " << db  << endl;
  cout << "b  = " <<  b ;
  cout << "x1 = " << xr1 << endl;
  cout << "x2 = " << xr2 << endl;
  cout << "N  = " << N  << endl;
  cout << "h  = " << step2 << endl;
  cout << '\v' ;
  cout << "Factor  = " << factor ;
  cout << '\v';
  
  /* L2-Norm des Datenfehlereinflusses */
  mpL2_RegError = mp_real(0.0);

  for(int jj = 0; jj <= N; jj++)
    {
      mpreg = mp_complex(0.0,0.0);
      x0 = xr1 + jj * step2;
      
      if(fabs(x0-x1) > fabs(xa)) wout <<"For x0 = " << x0 << endl;
      if(fabs(x0-x2) > fabs(xb)) wout <<"For x0 = " << x0 << endl;

      for(int j = 0; j <= M; j++)
	{
	  xi = x1 + j * stepreg;
	  xi = x0 - xi ;
	  //	  if (xi < xa) error("*** xi out of lowest samplepoint ***");
	  //	  if (xi > xb) error("*** xi out of upper samplepoint ***");
	  datae1linpol = real(edata(xi));
	  datae2linpol = imag(edata(xi));
	  mpcdata = mp_complex(datae1linpol,datae2linpol);
	  
	  mpreg += mpregkern[j]*mpcdata;
	}
      
      mpreg *= mpstepreg * factor;

      
      mpregtheo = Regtheo(mp_real(x0),b);
      mpRegRelError = abs(mpreg - mpregtheo)/abs(mpregtheo);
      mpRegRelError *= mp_real(100.0);
  
      mpL2_RegError += abs((mpreg - mpregtheo)*(mpreg - mpregtheo));
    
      cout << mp_real(x0) << mpreg << endl;
      cout << mpregtheo << mpRegRelError << endl;
      
      /* Konversion */
      reg = dble(MP_REAL(mpreg));
      regima = dble(aimag(mpreg));
      regtheo = dble(mpregtheo);
      RegRelError = dble(mpRegRelError);
      rout << x0 << '\t' << regtheo << '\t' << reg << '\t' << regima << '\t' << RegRelError << '\t' << db << endl;
      
    }
  
  mpL2_RegError *= step2;
  L2_RegError = dble(mpL2_RegError);
  
  double sigma = 1E-14;
  double L2asymp = UpperBound(sigma,db);
  cout << '\v';
  cout << "*** sigma        = " << sigma       <<" ***" << endl;
  cout << "*** L2-Regerror  = " << L2_RegError <<" ***" << endl;
  cout << "*** asymp. Error = " << L2asymp     <<" ***" << endl;  

  lout << "sigma" << '\t' << "L2-Regerror" <<'\t' << "asymp. Error" <<  endl;  
  lout << sigma << '\t' << L2_RegError  << '\t' << L2asymp <<  endl;  
  return 0;
}


