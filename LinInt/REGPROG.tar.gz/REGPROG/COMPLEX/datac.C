#include <math.h>         // Default Mathematik-Bibliothek
#include "complex.H"      
#include "random.H"

const DComplex I = DComplex(0.0,1.0);

DComplex edata(double x)
{
  double xi;
  xi = Xi1double(x);
  //xi = 0.0;
  DComplex g;
  g = 1.0/(1.0 - I * exp(-x));
  g = g + 1E-01 * xi *(real(g) +I *imag(g));
  //  g += 1E-03 * (xi + I * xi);
  return g;

}

DComplex edata_exakt(double x)
{
  
  DComplex g;
  g = 1.0/(1.0 - I * exp(-x));
  return g;

}
